"""
AWS Lambda Function: Automated Thumbnail Generator & DynamoDB Event Recorder
Triggered by Amazon S3 's3:ObjectCreated:*' events or Amazon API Gateway.
Dependencies: Pillow, boto3, urllib
"""

import os
import io
import json
import urllib.parse
from datetime import datetime
import boto3
from PIL import Image

# Initialize AWS clients
s3_client = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")

# Target DynamoDB table name from environment variable
TABLE_NAME = os.environ.get("DYNAMODB_TABLE_NAME", "IoTImageEvents")
THUMBNAIL_PREFIX = os.environ.get("THUMBNAIL_PREFIX", "thumbnails/")
THUMBNAIL_SIZE = (300, 300)


def lambda_handler(event, context):
    """
    AWS Lambda entry point.
    Handles both direct S3 notification events and API Gateway POST requests.
    """
    print("Received event:", json.dumps(event, indent=2))
    processed_records = []

    # Case 1: S3 Triggered Event
    if "Records" in event and len(event["Records"]) > 0:
        for record in event["Records"]:
            # Confirm event source is S3
            if record.get("eventSource") == "aws:s3":
                bucket = record["s3"]["bucket"]["name"]
                key = urllib.parse.unquote_plus(
                    record["s3"]["object"]["key"],
                    encoding="utf-8"
                )

                # Skip if already a thumbnail to avoid recursion loop
                if key.startswith(THUMBNAIL_PREFIX):
                    print(f"Skipping thumbnail key to prevent recursion: {key}")
                    continue

                res = process_s3_image(bucket, key)
                processed_records.append(res)

    # Case 2: API Gateway Triggered Event
    elif "body" in event:
        body = json.loads(event["body"]) if isinstance(event.get("body"), str) else event.get("body", {})
        bucket = body.get("bucket")
        key = body.get("key")
        if bucket and key:
            res = process_s3_image(bucket, key, device_id=body.get("device_id", "ESP32-CAM-01"))
            processed_records.append(res)
            return {
                "statusCode": 200,
                "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
                "body": json.dumps({"message": "Thumbnail generated successfully", "result": res})
            }

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": f"Processed {len(processed_records)} image(s) successfully.",
            "records": processed_records
        })
    }


def process_s3_image(bucket: str, original_key: str, device_id: str = "ESP32-CAM-01"):
    """
    Downloads original from S3, generates thumbnail with Pillow, uploads to S3,
    and records event details in DynamoDB.
    """
    print(f"Processing image: s3://{bucket}/{original_key}")

    # 1. Download original image into memory
    response = s3_client.get_object(Bucket=bucket, Key=original_key)
    image_bytes = response["Body"].read()
    file_size_kb = round(len(image_bytes) / 1024, 2)

    # 2. Extract base name and build thumbnail key
    filename = os.path.basename(original_key)
    base_name = os.path.splitext(filename)[0]
    thumb_key = f"{THUMBNAIL_PREFIX}{base_name}_thumb.jpg"

    # 3. Generate thumbnail using Pillow
    with Image.open(io.BytesIO(image_bytes)) as img:
        # Convert RGBA/P formats to standard RGB for JPEG output
        if img.mode in ("RGBA", "P"):
            img = img.convert("RGB")
        img.thumbnail(THUMBNAIL_SIZE, Image.Resampling.LANCZOS)
        thumb_buffer = io.BytesIO()
        img.save(thumb_buffer, format="JPEG", quality=85)
        thumb_bytes = thumb_buffer.getvalue()

    # 4. Upload thumbnail to S3
    s3_client.put_object(
        Bucket=bucket,
        Key=thumb_key,
        Body=thumb_bytes,
        ContentType="image/jpeg"
    )
    print(f"Uploaded thumbnail to: s3://{bucket}/{thumb_key}")

    # 5. Record metadata into DynamoDB table
    table = dynamodb.Table(TABLE_NAME)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    event_id = f"evt_{base_name[:12]}"

    item = {
        "event_id": event_id,
        "timestamp": timestamp,
        "filename": filename,
        "original_key": original_key,
        "thumbnail_key": thumb_key,
        "file_size_kb": str(file_size_kb),
        "device_id": device_id,
        "device_status": "Active",
        "led_status": "OFF",
        "processed_by": "AWS Lambda (Pillow)",
        "bucket": bucket
    }

    table.put_item(Item=item)
    print(f"Successfully recorded DynamoDB item for event {event_id}")

    return item
