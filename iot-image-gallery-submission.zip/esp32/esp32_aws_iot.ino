/*
  ESP32 AWS IoT Core MQTT Client with LED Status Indicator
  ---------------------------------------------------------
  Project: IoT Image Gallery Dashboard
  Hardware: ESP32 DevKit (or ESP32-CAM)
  
  Features:
  - Secure TLS connection to AWS IoT Core (Port 8883)
  - Subscribes to capture commands from Streamlit dashboard
  - Onboard LED turns ON during capture event, OFF when finished
  - Publishes device status (Active) & heartbeat telemetry
*/

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h> // Library: PubSubClient by Nick O'Leary
#include <ArduinoJson.h>  // Library: ArduinoJson by Benoit Blanchon

// --- Network & AWS Configuration ---
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// AWS IoT Core Endpoint (from AWS IoT Core Settings page)
const char* AWS_IOT_ENDPOINT = "YOUR_AWS_IOT_ENDPOINT.iot.us-east-1.amazonaws.com";
const int   AWS_IOT_PORT     = 8883;
const char* CLIENT_ID        = "ESP32_Edge_Camera_01";

// MQTT Topics
const char* TOPIC_COMMANDS   = "esp32/camera/commands";
const char* TOPIC_TELEMETRY  = "esp32/camera/telemetry";

// Onboard LED Pin (GPIO 2 on ESP32 DevKit, GPIO 33 on AI-Thinker ESP32-CAM)
const int LED_PIN = 2;

// --- AWS IoT X.509 Device Certificates ---
// Paste your downloaded certificates from AWS IoT Core console below
static const char AWS_CERT_CA[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
... PASTE YOUR AmazonRootCA1.pem HERE ...
-----END CERTIFICATE-----
)EOF";

static const char AWS_CERT_CRT[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
... PASTE YOUR certificate.pem.crt HERE ...
-----END CERTIFICATE-----
)EOF";

static const char AWS_CERT_PRIVATE[] PROGMEM = R"EOF(
-----BEGIN RSA PRIVATE KEY-----
... PASTE YOUR private.pem.key HERE ...
-----END RSA PRIVATE KEY-----
)EOF";

WiFiClientSecure netClient;
PubSubClient mqttClient(netClient);

void setLed(bool state) {
  digitalWrite(LED_PIN, state ? HIGH : LOW);
  Serial.print("[LED] State is now: ");
  Serial.println(state ? "ON" : "OFF");
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  Serial.print("[MQTT] Message arrived on topic: ");
  Serial.println(topic);

  // Parse JSON command payload
  StaticJsonDocument<256> doc;
  DeserializationError err = deserializeJson(doc, payload, length);
  if (err) {
    Serial.print("[MQTT] JSON parse error: ");
    Serial.println(err.c_str());
    return;
  }

  const char* action = doc["action"]; // e.g. "CAPTURE_EVENT"

  if (strcmp(action, "CAPTURE_EVENT") == 0) {
    Serial.println("[ACTION] Capture Event triggered from Dashboard!");
    
    // 1. Turn LED ON
    setLed(true);
    publishTelemetry("CAPTURING", "ON");

    // Simulate camera capture exposure time
    delay(1200);

    // 2. Turn LED OFF
    setLed(false);
    publishTelemetry("ACTIVE", "OFF");
    Serial.println("[ACTION] Capture Event completed.");
  }
}

void publishTelemetry(const char* deviceStatus, const char* ledStatus) {
  StaticJsonDocument<200> doc;
  doc["device_id"] = "ESP32-CAM-01";
  doc["device_status"] = deviceStatus;
  doc["led_status"] = ledStatus;
  doc["wifi_rssi"] = WiFi.RSSI();
  doc["uptime_ms"] = millis();

  char buffer[256];
  serializeJson(doc, buffer);
  mqttClient.publish(TOPIC_TELEMETRY, buffer);
  Serial.print("[MQTT] Telemetry published: ");
  Serial.println(buffer);
}

void connectWiFi() {
  Serial.print("[WiFi] Connecting to: ");
  Serial.println(WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\n[WiFi] Connected! IP Address: ");
  Serial.println(WiFi.localIP());
}

void connectAWS() {
  // Configure secure TLS client with certificates
  netClient.setCACert(AWS_CERT_CA);
  netClient.setCertificate(AWS_CERT_CRT);
  netClient.setPrivateKey(AWS_CERT_PRIVATE);

  mqttClient.setServer(AWS_IOT_ENDPOINT, AWS_IOT_PORT);
  mqttClient.setCallback(mqttCallback);

  while (!mqttClient.connected()) {
    Serial.print("[AWS IoT] Attempting MQTT connection...");
    if (mqttClient.connect(CLIENT_ID)) {
      Serial.println("Connected to AWS IoT Core!");
      mqttClient.subscribe(TOPIC_COMMANDS);
      Serial.print("[AWS IoT] Subscribed to topic: ");
      Serial.println(TOPIC_COMMANDS);
      publishTelemetry("Active", "OFF");
    } else {
      Serial.print("Failed, rc=");
      Serial.print(mqttClient.state());
      Serial.println(". Retrying in 5 seconds...");
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  setLed(false);

  connectWiFi();
  connectAWS();
}

unsigned long lastPing = 0;

void loop() {
  if (!mqttClient.connected()) {
    connectAWS();
  }
  mqttClient.loop();

  // Send heartbeat telemetry every 30 seconds
  if (millis() - lastPing > 30000) {
    lastPing = millis();
    publishTelemetry("Active", "OFF");
  }
}
