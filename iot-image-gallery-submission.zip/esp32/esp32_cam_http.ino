/*
  ESP32-CAM HTTP Post Image Upload
  --------------------------------
  Captures a live frame from OV2640 camera, flashes the onboard LED,
  and uploads the JPEG image to API Gateway / S3 Pre-signed URL.
*/

#include "esp_camera.h"
#include <WiFi.h>
#include <HTTPClient.h>

const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";
// API Gateway or Local Server URL
const char* uploadUrl = "http://192.168.1.100:8501"; 

// AI-Thinker Pin Definitions
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

// Onboard Flash LED (GPIO 4) or Red Status LED (GPIO 33)
#define FLASH_LED_PIN      4

void setupCamera() {
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sscb_sda = SIOD_GPIO_NUM;
  config.pin_sscb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;
  config.frame_size = FRAMESIZE_SVGA; // 800x600 for optimal transfer speed
  config.jpeg_quality = 12;
  config.fb_count = 1;

  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("[CAMERA] Camera init failed: 0x%x\n", err);
  }
}

void captureAndUpload() {
  // Flash LED ON during capture
  digitalWrite(FLASH_LED_PIN, HIGH);
  delay(100);

  camera_fb_t * fb = esp_camera_fb_get();
  
  // Turn Flash LED OFF
  digitalWrite(FLASH_LED_PIN, LOW);

  if(!fb) {
    Serial.println("[CAMERA] Capture failed");
    return;
  }

  Serial.printf("[CAMERA] Frame captured! Size: %u bytes\n", fb->len);

  // Send to server
  HTTPClient http;
  http.begin(uploadUrl);
  http.addHeader("Content-Type", "image/jpeg");
  http.addHeader("X-Device-ID", "ESP32-CAM-01");

  int code = http.POST(fb->buf, fb->len);
  Serial.printf("[HTTP] POST Response code: %d\n", code);

  http.end();
  esp_camera_fb_return(fb);
}

void setup() {
  Serial.begin(115200);
  pinMode(FLASH_LED_PIN, OUTPUT);
  digitalWrite(FLASH_LED_PIN, LOW);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\n[WiFi] Connected!");
  setupCamera();
}

void loop() {
  // Wait for command or periodic capture
  delay(10000);
}
