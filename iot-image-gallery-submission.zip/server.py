#!/usr/bin/env python3
"""
IoT Image Gallery Dashboard Backend Server
Zero-dependency Python HTTP Server with REST APIs for IoT Cameras (ESP32-CAM, Raspberry Pi)
Supports:
  - POST /api/upload        : Ingest image capture + sensor telemetry
  - GET  /api/images        : Fetch recent image captures
  - GET  /api/devices       : Fetch edge camera nodes status
  - POST /api/snapshot      : Send capture trigger to camera node
  - GET  /                  : Serves the IoT dashboard UI
"""

import os
import json
import time
import cgi
from http.server import HTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

PORT = 8080
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CAPTURES_DIR = os.path.join(BASE_DIR, "captures")
DATA_FILE = os.path.join(BASE_DIR, "captures_db.json")

os.makedirs(CAPTURES_DIR, exist_ok=True)

# Initial sample devices
DEVICES = {
    "GATE-CAM-01": {"name": "Entrance Gate", "type": "ESP32-CAM", "status": "online", "battery": 92, "temp": 26.4, "rssi": -54},
    "WHSE-BAY-4": {"name": "Warehouse Bay 4", "type": "Raspberry Pi 4 HQ", "status": "online", "battery": 88, "temp": 22.1, "rssi": -62},
    "THERMAL-NIGHT": {"name": "Substation Thermal", "type": "FLIR Lepton", "status": "alert", "battery": 97, "temp": 42.8, "rssi": -48},
    "SOLAR-FARM-01": {"name": "Solar Array", "type": "Edge AI Cam", "status": "online", "battery": 100, "temp": 28.5, "rssi": -58},
}

def load_captures():
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return []
    return []

def save_captures(captures):
    with open(DATA_FILE, "w") as f:
        json.dump(captures, f, indent=2)

class IoTDashboardHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        # Enable CORS for edge development
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)

        if parsed.path == "/" or parsed.path == "/index.html":
            self.path = "/index.html"
            return super().do_GET()

        elif parsed.path.startswith("/captures/"):
            return super().do_GET()

        elif parsed.path == "/api/images":
            captures = load_captures()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(captures).encode("utf-8"))

        elif parsed.path == "/api/devices":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(DEVICES).encode("utf-8"))

        else:
            return super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)

        if parsed.path == "/api/upload":
            content_type = self.headers.get("Content-Type", "")
            
            if "multipart/form-data" in content_type:
                form = cgi.FieldStorage(
                    fp=self.rfile,
                    headers=self.headers,
                    environ={'REQUEST_METHOD': 'POST', 'CONTENT_TYPE': content_type}
                )

                node_id = form.getvalue("node_id", "CAM-UNKNOWN")
                battery = float(form.getvalue("battery", 85.0))
                temp = float(form.getvalue("temp", 25.0))
                rssi = int(form.getvalue("rssi", -60))
                event_type = form.getvalue("event_type", "AI_DETECTION")

                fileitem = form['image'] if 'image' in form else None
                if fileitem and fileitem.file:
                    filename = f"cap_{int(time.time())}_{node_id}.jpg"
                    filepath = os.path.join(CAPTURES_DIR, filename)
                    with open(filepath, 'wb') as f:
                        f.write(fileitem.file.read())

                    new_capture = {
                        "id": f"CAP-{int(time.time() % 10000)}",
                        "nodeId": node_id,
                        "nodeName": f"Edge Node {node_id}",
                        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
                        "relativeTime": "Just now",
                        "resolution": "1920x1080",
                        "fileSize": f"{os.path.getsize(filepath) // 1024} KB",
                        "eventType": event_type,
                        "imageUrl": f"/captures/{filename}",
                        "battery": int(battery),
                        "temp": temp,
                        "rssi": rssi,
                        "detections": [{"label": "Edge Object", "confidence": 94.5, "color": "cyan"}]
                    }

                    caps = load_captures()
                    caps.insert(0, new_capture)
                    save_captures(caps)

                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(json.dumps({"status": "success", "capture": new_capture}).encode("utf-8"))
                    return

            self.send_response(400)
            self.end_headers()
            self.wfile.write(b'{"error": "Invalid form-data or missing image"}')

        elif parsed.path == "/api/snapshot":
            # Simulation response for snapshot trigger
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status": "triggered", "message": "Snapshot signal broadcasted via MQTT/HTTP"}')

        else:
            self.send_response(404)
            self.end_headers()

if __name__ == "__main__":
    os.chdir(BASE_DIR)
    print(f"==================================================")
    print(f" IoT Edge Vision Hub Server Running")
    print(f" Access Dashboard: http://localhost:{PORT}")
    print(f" Upload Endpoint : http://localhost:{PORT}/api/upload")
    print(f"==================================================")
    server = HTTPServer(("0.0.0.0", PORT), IoTDashboardHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server...")
        server.server_close()
