"""
==============================================================================
IoT Image Gallery - Streamlit Dashboard
College Submission Project
------------------------------------------------------------------------------
Technologies: Python, Streamlit, ESP32, AWS IoT Core, S3, Lambda, API Gateway, DynamoDB
Theme: Professional Light-Blue and Cyan
==============================================================================
"""

import os
import io
import time
from datetime import datetime
import streamlit as st
from PIL import Image

# Local utilities
from utils.ui_theme import apply_theme
import utils.local_storage as local_db
from utils.aws_client import AWSManager

# Page Configuration
st.set_page_config(
    page_title="IoT Image Gallery Hub",
    page_icon="📷",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Apply Light-Blue & Cyan CSS Theme
st.markdown(apply_theme(), unsafe_allow_html=True)

# Initialize Session State
if "app_mode" not in st.session_state:
    st.session_state.app_mode = os.getenv("APP_MODE", "Local Simulator")
if "last_action_msg" not in st.session_state:
    st.session_state.last_action_msg = "System initialized and ready."
if "led_override" not in st.session_state:
    st.session_state.led_override = None

# Ensure sample images are seeded if empty
local_db.seed_sample_data()

# Initialize AWS Manager (graceful, will not crash if offline)
aws_mgr = AWSManager()

# ==============================================================================
# SIDEBAR CONTROLS & AWS CONFIGURATION
# ==============================================================================
with st.sidebar:
    st.image(
        "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=600&q=80",
        caption="IoT Edge Vision Node",
        use_container_width=True
    )
    
    st.markdown("### ⚙️ System Controls")
    
    # Mode Selector: Local Simulator vs AWS Cloud
    selected_mode = st.radio(
        "Operation Mode:",
        ["Local Simulator", "AWS Cloud Mode"],
        index=0 if st.session_state.app_mode == "Local Simulator" else 1,
        help="Local Simulator works offline without AWS. Switch to AWS Cloud when your AWS resources are provisioned."
    )
    st.session_state.app_mode = selected_mode

    st.markdown("---")
    st.markdown("### 📡 ESP32 Hardware Status")
    
    current_state = local_db.load_device_state()
    is_active = current_state.get("device_status") == "Active"
    
    # Toggle ESP32 Active / Inactive
    active_toggle = st.toggle("ESP32 Device Power", value=is_active, help="Simulate ESP32 device being online or offline.")
    if active_toggle != is_active:
        local_db.set_esp32_status(active_toggle)
        st.rerun()

    # Manual LED Override toggle for demonstration
    st.markdown("### 💡 Onboard LED Test")
    led_state = current_state.get("led_status", "OFF")
    col_led_a, col_led_b = st.columns(2)
    with col_led_a:
        if st.button("Turn LED ON", use_container_width=True):
            local_db.set_led_status(True)
            st.session_state.last_action_msg = "LED turned ON manually."
            st.rerun()
    with col_led_b:
        if st.button("Turn LED OFF", use_container_width=True):
            local_db.set_led_status(False)
            st.session_state.last_action_msg = "LED turned OFF manually."
            st.rerun()

    st.markdown("---")
    st.markdown("### ☁️ AWS Cloud Health Check")
    if selected_mode == "AWS Cloud Mode":
        if st.button("Test AWS Connection"):
            with st.spinner("Connecting to AWS Services..."):
                ok, msg = aws_mgr.test_connection()
                if ok:
                    st.success(msg)
                else:
                    st.error(msg)
                    st.info("Check `.env` file or run `aws configure` in terminal.")
    else:
        st.info("Operating in **Local Simulator Mode**.\nAll S3, DynamoDB, and Lambda Pillow functions run locally.")

    st.markdown("---")
    st.caption("College Submission Project • IoT Image Gallery")


# ==============================================================================
# MAIN DASHBOARD HEADER
# ==============================================================================
st.markdown("""
<div class="dashboard-header">
    <div>
        <div class="dashboard-title">
            <span>📷</span> IoT Image Gallery & Edge Vision Hub
        </div>
        <div class="dashboard-subtitle">
            ESP32 Microcontroller • AWS IoT Core • S3 • Lambda (Pillow) • DynamoDB • API Gateway
        </div>
    </div>
    <div style="text-align: right;">
        <span style="background: rgba(255,255,255,0.25); padding: 6px 14px; border-radius: 20px; font-weight: 600; font-size: 0.85rem;">
            Mode: """ + ("Local Demo" if st.session_state.app_mode == "Local Simulator" else "AWS Cloud") + """
        </span>
    </div>
</div>
""", unsafe_allow_html=True)


# ==============================================================================
# DATA RETRIEVAL (Local or AWS)
# ==============================================================================
device_state = local_db.load_device_state()
device_status = device_state.get("device_status", "Active")
led_status = device_state.get("led_status", "OFF")

if st.session_state.app_mode == "AWS Cloud Mode":
    events = aws_mgr.fetch_events_from_dynamodb()
    storage_label = "Amazon S3 + DynamoDB"
else:
    events = local_db.load_events()
    storage_label = "Local S3 Simulator"

total_images = len(events)
latest_event_time = events[0].get("timestamp", "None") if total_images > 0 else "No events yet"


# ==============================================================================
# METRIC CARDS ROW
# ==============================================================================
col_m1, col_m2, col_m3, col_m4, col_m5 = st.columns(5)

with col_m1:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-title">Total Images</div>
        <div class="metric-value">{total_images}</div>
    </div>
    """, unsafe_allow_html=True)

with col_m2:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-title">Latest Event Time</div>
        <div class="metric-value" style="font-size: 1.05rem; padding-top: 6px;">{latest_event_time}</div>
    </div>
    """, unsafe_allow_html=True)

with col_m3:
    status_cls = "status-active" if device_status == "Active" else "status-inactive"
    dot_char = "🟢" if device_status == "Active" else "⚪"
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-title">ESP32 Device Status</div>
        <div style="margin-top: 8px;">
            <span class="status-pill {status_cls}">{dot_char} {device_status}</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

with col_m4:
    led_cls = "led-indicator-on" if led_status == "ON" else "led-indicator-off"
    dot_cls = "led-dot-on" if led_status == "ON" else "led-dot-off"
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-title">LED Status</div>
        <div style="margin-top: 8px;">
            <span class="{led_cls}">
                <span class="{dot_cls}"></span> LED {led_status}
            </span>
        </div>
    </div>
    """, unsafe_allow_html=True)

with col_m5:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-title">Upload Status</div>
        <div class="metric-value" style="font-size: 1.0rem; color: #0284c7; padding-top: 8px;">
            Ready
        </div>
    </div>
    """, unsafe_allow_html=True)


# ==============================================================================
# ACTIONS & CONTROLS ROW
# ==============================================================================
st.markdown("<br>", unsafe_allow_html=True)
action_col1, action_col2 = st.columns([1, 1], gap="medium")

# ACTION 1: CAPTURE EVENT BUTTON
with action_col1:
    st.markdown("#### 🚀 Trigger Capture Event")
    st.write("Send a live capture trigger to the ESP32 node. The onboard LED will illuminate while capturing.")
    
    if st.button("📸 Capture Event", use_container_width=True, type="primary"):
        if device_status != "Active":
            st.error("⚠️ Cannot trigger capture: ESP32 device status is currently Inactive!")
        else:
            with st.status("📡 Dispatched Capture Signal to ESP32...", expanded=True) as status_box:
                # 1. Turn LED ON
                local_db.set_led_status(True)
                st.write("💡 Onboard LED turned **ON** for exposure...")
                time.sleep(0.8)
                
                # 2. Capture and process image
                st.write("📷 Frame acquired from camera sensor...")
                if st.session_state.app_mode == "Local Simulator":
                    rec = local_db.trigger_esp32_capture_simulation()
                else:
                    # In Cloud mode, generate synthetic frame or call API Gateway
                    img_bytes = local_db.create_synthetic_iot_image("ESP32 Cloud Snapshot", "AWS IoT Core Triggered", "cyan")
                    rec = aws_mgr.upload_image_and_record_event(
                        img_bytes,
                        f"esp32_cloud_{int(time.time())}.jpg",
                        device_id="ESP32-CAM-01",
                        device_status="Active",
                        led_status="ON",
                        event_source="AWS IoT Core MQTT"
                    )

                # 3. Pillow Thumbnail generation
                st.write("✨ Thumbnail automatically generated using Pillow...")
                time.sleep(0.4)

                # 4. Turn LED OFF
                local_db.set_led_status(False)
                st.write("💡 Onboard LED turned **OFF**.")
                
                status_box.update(label=f"✅ Capture Complete! Event ID: {rec.get('event_id')}", state="complete")
                st.session_state.last_action_msg = f"Capture Event {rec.get('event_id')} stored successfully."
                time.sleep(0.5)
                st.rerun()

# ACTION 2: MANUAL IMAGE UPLOAD
with action_col2:
    st.markdown("#### 📤 Upload Custom Image")
    st.write("Upload a JPG, JPEG, or PNG image. Thumbnails are auto-generated via Pillow & stored in S3.")
    
    uploaded_file = st.file_uploader(
        "Choose an image file",
        type=["jpg", "jpeg", "png"],
        help="Supported formats: JPG, JPEG, PNG"
    )
    
    if uploaded_file is not None:
        if st.button("💾 Process & Store Image", use_container_width=True):
            with st.spinner("Processing image and generating Pillow thumbnail..."):
                file_bytes = uploaded_file.read()
                
                if st.session_state.app_mode == "Local Simulator":
                    record = local_db.store_image_event(
                        image_bytes=file_bytes,
                        original_filename=uploaded_file.name,
                        event_source="User Upload (Local)"
                    )
                else:
                    record = aws_mgr.upload_image_and_record_event(
                        image_bytes=file_bytes,
                        filename=uploaded_file.name,
                        device_id=device_state.get("device_id", "ESP32-CAM-01"),
                        device_status=device_status,
                        led_status="OFF",
                        event_source="User Upload (AWS S3)"
                    )
                
                st.success(f"🎉 Successfully saved **{uploaded_file.name}**! Event ID: `{record.get('event_id')}`")
                time.sleep(0.6)
                st.rerun()


# ==============================================================================
# IMAGE GALLERY DISPLAY
# ==============================================================================
st.markdown("---")
gallery_header_col1, gallery_header_col2 = st.columns([3, 1])

with gallery_header_col1:
    st.markdown("### 🖼️ IoT Image Gallery")
    st.caption(f"Showing {total_images} captures stored in {storage_label}")

with gallery_header_col2:
    view_type = st.radio("View Format:", ["Thumbnails (Lambda/Pillow)", "Full Originals (S3)"], horizontal=True)

if total_images == 0:
    st.info("No images uploaded yet. Click **'📸 Capture Event'** or upload an image to get started!")
else:
    # Display images in responsive 3-column grid
    cols = st.columns(3)
    
    for idx, event in enumerate(events):
        with cols[idx % 3]:
            # Determine path or URL to load
            is_thumb_view = "Thumbnails" in view_type
            
            # Local Mode Path
            if st.session_state.app_mode == "Local Simulator":
                img_path = event.get("thumbnail_path") if is_thumb_view else event.get("original_path")
                # Fallback if specific file missing
                if not img_path or not os.path.exists(img_path):
                    img_path = event.get("original_path")
                
                try:
                    display_image = Image.open(img_path)
                except Exception:
                    display_image = None
            else:
                # AWS Cloud Mode Pre-signed URL
                img_url = event.get("thumbnail_url") if is_thumb_view else event.get("original_url")
                display_image = img_url or "https://via.placeholder.com/300x200?text=S3+Image"

            # Render Card Container
            with st.container():
                st.markdown('<div class="gallery-card">', unsafe_allow_html=True)
                
                if display_image:
                    st.image(
                        display_image,
                        caption=event.get("filename", "Camera Capture"),
                        use_container_width=True
                    )
                else:
                    st.warning("Image preview unavailable.")

                # Metadata tags
                st.markdown(f"""
                <div class="gallery-meta">
                    <div class="gallery-meta-row">
                        <span><strong>Event ID:</strong> <code>{event.get('event_id', 'N/A')}</code></span>
                        <span class="gallery-tag">{event.get('event_source', 'ESP32')}</span>
                    </div>
                    <div class="gallery-meta-row">
                        <span>⏱️ {event.get('timestamp', 'N/A')}</span>
                        <span>📦 {event.get('file_size_kb', '0')} KB</span>
                    </div>
                    <div class="gallery-meta-row">
                        <span>Node: <strong>{event.get('device_id', 'ESP32-CAM')}</strong></span>
                        <span>LED: <strong>{event.get('led_status', 'OFF')}</strong></span>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                st.markdown('</div>', unsafe_allow_html=True)

# Footer
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #64748b; font-size: 0.85rem; padding: 10px 0;">
    IoT Image Gallery System • Built with Python, Streamlit, ESP32, AWS IoT Core, S3, Lambda & DynamoDB
</div>
""", unsafe_allow_html=True)
