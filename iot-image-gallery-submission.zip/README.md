# 📷 IoT Image Gallery & Edge Vision Hub

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.30%2B-FF4B4B.svg)](https://streamlit.io/)
[![AWS](https://img.shields.io/badge/AWS-S3%20%7C%20Lambda%20%7C%20DynamoDB%20%7C%20IoT%20Core-FF9900.svg)](https://aws.amazon.com/)
[![ESP32](https://img.shields.io/badge/ESP32-Arduino%20C%2B%2B-teal.svg)](https://www.espressif.com/)
[![License](https://img.shields.io/badge/Academic-Submission-success.svg)]()

A complete, production-ready **IoT Image Gallery Dashboard** built for college submissions and viva demonstrations. The system features a responsive **Light-Blue and Cyan** interface, simulated and cloud-connected **ESP32 microcontroller triggers**, **LED status indicators**, **automated thumbnail generation via Pillow & AWS Lambda**, **Amazon S3 object storage**, and **Amazon DynamoDB metadata logging**.

---

## 🌟 Key Features

1. **🎨 Professional Light-Blue & Cyan Theme**: Clean glassmorphism styling, responsive card grids, hover animations, and glowing indicators.
2. **📸 On-Demand Capture Event**: One-click capture trigger simulating camera frame acquisition with synchronized LED ON/OFF exposure states.
3. **📡 ESP32 Device & LED Status**: Real-time status cards displaying device connectivity (`Active`/`Inactive`) and onboard LED states (`ON`/`OFF`).
4. **🖼️ Dual View Image Gallery**: Switch seamlessly between lightweight thumbnails and full-resolution S3 originals.
5. **⚡ Automated Thumbnail Generation**: Pillow-powered image resizing maintaining aspect ratios and reducing bandwidth consumption.
6. **☁️ Hybrid Offline / AWS Cloud Mode**:
   - **Local Simulator (Default)**: Runs 100% offline out-of-the-box with pre-seeded IoT images. Perfect for quick testing and viva demos!
   - **AWS Cloud Mode**: Integrates live with Amazon S3, AWS Lambda, Amazon DynamoDB, and API Gateway.
7. **🔒 Zero Hardcoded Credentials**: Strictly adheres to AWS security standards via `.env` templates and standard AWS credential chains.

---

## 🏛️ System Architecture

```mermaid
flowchart LR
    subgraph Edge ["ESP32 Edge Device"]
        E1[ESP32 / ESP32-CAM]
        LED[Onboard Status LED]
        E1 <--> LED
    end

    subgraph AWS ["Amazon Web Services (AWS)"]
        IOT[AWS IoT Core MQTT]
        APIGW[Amazon API Gateway]
        S3O["Amazon S3 (originals/)"]
        LAMBDA["AWS Lambda (Pillow Layer)"]
        S3T["Amazon S3 (thumbnails/)"]
        DDB[Amazon DynamoDB]

        E1 -->|TLS Port 8883| IOT
        E1 -->|HTTP POST| APIGW
        APIGW --> S3O
        S3O -->|S3 Event Trigger| LAMBDA
        LAMBDA -->|Resize 300x300| S3T
        LAMBDA -->|Save Metadata| DDB
    end

    subgraph Dashboard ["Student Dashboard (Streamlit)"]
        UI["app.py (Streamlit UI)"]
        UI -->|Fetch Metadata| DDB
        UI -->|Pre-signed URLs| S3T
        UI -->|Trigger Event| IOT
    end
```

---

## 📂 Project Directory Structure

```text
iot-image-gallery/
├── app.py                      # Main Streamlit Dashboard (Theme, metrics, gallery, event controls)
├── requirements.txt            # Python dependencies
├── .env.example                # Safe environment variables configuration template
├── .gitignore                  # Prevents committing secrets, cache, or credentials
├── README.md                   # Comprehensive guide and college submission documentation
├── utils/
│   ├── __init__.py
│   ├── ui_theme.py             # Custom Light-Blue & Cyan CSS styling engine
│   ├── local_storage.py        # Local S3, DynamoDB, and Pillow thumbnail emulator
│   └── aws_client.py           # Boto3 client wrapper for S3, DynamoDB & API Gateway
├── aws/
│   ├── lambda/
│   │   ├── lambda_function.py  # Production AWS Lambda thumbnail generator code
│   │   └── requirements.txt    # Pillow and Boto3 dependencies for Lambda layer
│   ├── api_gateway/
│   │   └── openapi_spec.json   # REST API Gateway specification
│   └── dynamodb/
│       └── schema.json         # DynamoDB table definition & sample records
├── esp32/
│   ├── esp32_aws_iot.ino       # ESP32 sketch for AWS IoT Core MQTT + LED control
│   └── esp32_cam_http.ino      # ESP32-CAM sketch for HTTP image capture & upload
└── tests/
    └── test_dashboard.py       # Automated test suite (6 passing test cases)
```

---

## 🚀 Quick Start Guide (Run Locally in 2 Minutes)

You do **not** need an AWS account to test this right away. The local simulator runs immediately.

### 1. Open Terminal and Navigate to Project Directory

```powershell
cd iot-image-gallery
```

### 2. Install Required Python Packages

```powershell
python -m pip install -r requirements.txt
```

### 3. Verify Automated Tests

```powershell
python -m pytest tests/test_dashboard.py
```
*(All 6 tests should pass: thumbnail generation, event capturing, device state toggles, and data persistence).*

### 4. Run the Streamlit Dashboard

```powershell
python -m streamlit run app.py
```

Your browser will automatically open:
👉 **`http://localhost:8501`**

---

## ☁️ Step-by-Step AWS Deployment Walkthrough

When you are ready to connect the project to your live AWS account, follow these steps:

### Step 1: Create Amazon S3 Bucket
1. Open the **AWS Management Console** and navigate to **S3**.
2. Click **Create bucket**.
3. Bucket name: e.g., `iot-gallery-storage-<your-roll-number>`.
4. Leave other settings as default and click **Create bucket**.
5. Inside your new bucket, create two folders:
   - `originals/`
   - `thumbnails/`

### Step 2: Create Amazon DynamoDB Table
1. Navigate to **DynamoDB** in the AWS Console.
2. Click **Create table**.
3. **Table name**: `IoTImageEvents`
4. **Partition key (Hash)**: `event_id` (String `S`)
5. **Table class**: Standard, Capacity: On-demand (`PAY_PER_REQUEST`).
6. Click **Create table**.

*(Alternatively via AWS CLI)*:
```bash
aws dynamodb create-table \
    --table-name IoTImageEvents \
    --attribute-definitions AttributeName=event_id,AttributeType=S \
    --key-schema AttributeName=event_id,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST
```

### Step 3: Create AWS Lambda Function with Pillow
1. Navigate to **AWS Lambda** -> **Create function**.
2. Choose **Author from scratch**, Function name: `IoTImageThumbnailGenerator`.
3. Runtime: **Python 3.11** or **Python 3.12**.
4. In **Permissions**, attach the `AWSLambdaBasicExecutionRole`, `AmazonS3FullAccess`, and `AmazonDynamoDBFullAccess` (or custom least-privilege IAM policies).
5. Paste the code from `aws/lambda/lambda_function.py`.
6. **Add Pillow Layer**:
   - In Lambda, scroll down to **Layers** -> **Add a layer**.
   - Select AWS Layers: `Klayers-p311-Pillow` or upload a zip package containing Pillow.
7. **Add S3 Trigger**:
   - Click **Add trigger** -> Select **S3**.
   - Bucket: Your created S3 bucket.
   - Event types: `All object create events` (`s3:ObjectCreated:*`).
   - Prefix: `originals/`

### Step 4: Configure Local `.env` File
1. Copy `.env.example` to `.env`:
   ```powershell
   Copy-Item .env.example .env
   ```
2. Open `.env` and fill in your bucket name, region, and credentials:
   ```env
   APP_MODE=aws
   AWS_DEFAULT_REGION=us-east-1
   S3_BUCKET_NAME=iot-gallery-storage-yourid
   DYNAMODB_TABLE_NAME=IoTImageEvents
   ```
3. Restart the Streamlit dashboard or switch the sidebar radio button to **AWS Cloud Mode**.

---

## 🔌 ESP32 Microcontroller Setup (Hardware)

### Required Hardware
- 1x **ESP32 DevKit** (or ESP32-CAM AI-Thinker)
- 1x **LED** + 220Ω resistor (connected between GPIO 2 and GND)
- Micro-USB cable

### Arduino IDE Instructions
1. Install **Arduino IDE** (version 2.x recommended).
2. Go to **File -> Preferences**, and add ESP32 board manager URL:
   `https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json`
3. Go to **Tools -> Board -> Board Manager**, search for `esp32` by Espressif and click **Install**.
4. Install Libraries via Library Manager (`Ctrl+Shift+I`):
   - `PubSubClient` by Nick O'Leary
   - `ArduinoJson` by Benoit Blanchon
5. Open `esp32/esp32_aws_iot.ino`.
6. Enter your Wi-Fi SSID, Password, and AWS IoT Core endpoint.
7. Paste your X.509 device certificate, private key, and Amazon Root CA.
8. Connect ESP32 via USB and click **Upload**.

---

## 🎓 College Viva & Interview Preparation (Q&A)

### Q1: Why do we generate thumbnails on AWS Lambda instead of on the ESP32?
> **Answer**: The ESP32 is a low-power microcontroller with limited RAM (typically 520 KB SRAM). Decoding and resizing high-resolution JPEG images requires heavy memory buffers and processing power. Offloading image resizing to serverless AWS Lambda frees up the microcontroller to focus exclusively on camera capture and sensor telemetry.

### Q2: What is the benefit of storing image metadata in DynamoDB while storing image binaries in S3?
> **Answer**: S3 is an object store optimized for storing large binary objects cost-effectively. However, querying binary stores for filtering by timestamp, device status, or event ID is inefficient. DynamoDB is a NoSQL database that offers single-digit millisecond latency for metadata queries, pagination, and sorting.

### Q3: How is security handled between the ESP32 and AWS IoT Core?
> **Answer**: AWS IoT Core uses TLS 1.2 mutual authentication (mTLS) on port 8883. The ESP32 holds a unique X.509 certificate and private key, ensuring all data in transit is encrypted and only authorized hardware nodes can publish commands or telemetry.

### Q4: What happens if AWS goes offline during a presentation?
> **Answer**: The project includes a full **Local Simulator Mode** that emulates S3, DynamoDB, and Pillow resizing locally. You can demonstrate every feature seamlessly even with zero internet connectivity.
