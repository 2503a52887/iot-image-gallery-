"""
Unit & Integration Test Suite for IoT Image Gallery Dashboard
Tests local simulation engine, Pillow thumbnail generation, ESP32 device states,
and metadata persistence.
"""

import os
import io
import pytest
from PIL import Image

import utils.local_storage as local_db
from utils.aws_client import AWSManager


def test_seed_sample_data():
    """Verify default sample data is seeded and accessible."""
    local_db.seed_sample_data()
    events = local_db.load_events()
    assert len(events) >= 3, "Sample events were not seeded correctly"
    assert "event_id" in events[0]
    assert "timestamp" in events[0]
    assert "original_path" in events[0]


def test_generate_thumbnail_with_pillow():
    """Test Pillow thumbnail generation matches AWS Lambda behavior."""
    # Create test image 1200x800
    img = Image.new("RGB", (1200, 800), color="blue")
    in_io = io.BytesIO()
    img.save(in_io, format="JPEG")
    raw_bytes = in_io.getvalue()

    thumb_bytes = local_db.generate_thumbnail(raw_bytes, max_size=(300, 300))
    assert len(thumb_bytes) > 0, "Thumbnail bytes are empty"

    # Verify thumbnail dimensions
    with Image.open(io.BytesIO(thumb_bytes)) as thumb_img:
        width, height = thumb_img.size
        assert width <= 300 and height <= 300
        # Check aspect ratio 1200:800 = 1.5, so 300:200
        assert width == 300
        assert height == 200


def test_esp32_device_state_toggles():
    """Test device status and LED status persistence."""
    # Test active toggle
    state_active = local_db.set_esp32_status(True)
    assert state_active["device_status"] == "Active"

    state_inactive = local_db.set_esp32_status(False)
    assert state_inactive["device_status"] == "Inactive"

    # Reset to Active
    local_db.set_esp32_status(True)

    # Test LED toggle
    state_led_on = local_db.set_led_status(True)
    assert state_led_on["led_status"] == "ON"

    state_led_off = local_db.set_led_status(False)
    assert state_led_off["led_status"] == "OFF"


def test_capture_event_simulation():
    """Test the full Capture Event cycle."""
    initial_count = len(local_db.load_events())
    
    # Trigger event
    rec = local_db.trigger_esp32_capture_simulation()
    
    assert rec is not None
    assert rec["event_id"].startswith("evt_")
    assert os.path.exists(rec["original_path"])
    assert os.path.exists(rec["thumbnail_path"])
    assert rec["device_status"] == "Active"
    
    # Verify events list increased by 1
    updated_events = local_db.load_events()
    assert len(updated_events) == initial_count + 1


def test_custom_image_upload():
    """Test manual upload of custom PNG image."""
    img = Image.new("RGBA", (500, 500), color=(0, 200, 255, 255))
    in_io = io.BytesIO()
    img.save(in_io, format="PNG")
    raw_bytes = in_io.getvalue()

    rec = local_db.store_image_event(raw_bytes, "test_upload.png", event_source="Test Runner")
    assert rec["filename"] == "test_upload.png"
    assert os.path.exists(rec["original_path"])
    assert os.path.exists(rec["thumbnail_path"])


def test_aws_client_graceful_handling():
    """Verify AWS manager handles unconfigured credentials safely without crashing."""
    mgr = AWSManager()
    is_ok, msg = mgr.test_connection()
    # It should either succeed (if credentials configured) or fail gracefully with a message
    assert isinstance(is_ok, bool)
    assert isinstance(msg, str)
