/**
 * IoT Image Gallery Dashboard - Application Controller
 * Anti-Gravity College / Engineering Project Implementation
 * 
 * Features:
 * - Single Page App (SPA) Navigation (Dashboard, Capture, Gallery, Settings)
 * - Live Metrics: Total Images, Today's Images, Storage Size, Thumbnails
 * - Real-time Webcam Stream & Snapshot Capture
 * - Drag-and-drop / File Upload
 * - Simulated ESP32-CAM Hardware Edge Trigger with Telemetry
 * - Client-side HTML5 Canvas Auto-Thumbnail Generator
 * - Offline-first IndexedDB Cloud Storage Emulation
 * - Search, Device Filter, Date Filter, and JSON Export
 * - Full-resolution Lightbox with Download & Delete actions
 * - Auto-seeding of initial sample captures for immediate presentation readiness
 */

(function () {
  'use strict';

  // --- IndexedDB Setup ---
  const DB_NAME = 'IoTImageGalleryDB';
  const DB_VERSION = 1;
  const STORE_NAME = 'gallery_records';
  let db = null;

  // --- Application State ---
  let allImages = [];
  let mediaStream = null;
  let stagedCapture = null;
  let currentViewingImage = null;

  // --- Cache DOM Elements ---
  // Navigation
  const sidebar = document.getElementById('sidebar');
  const menuToggleBtn = document.getElementById('menuToggleBtn');
  const navItems = document.querySelectorAll('.sidebar-nav .nav-item');
  const viewContainers = document.querySelectorAll('.view-container');
  const navGalleryCount = document.getElementById('navGalleryCount');
  const liveClock = document.getElementById('liveClock');
  const quickCaptureNavBtn = document.getElementById('quickCaptureNavBtn');

  // Dashboard Overview
  const cardTotalImages = document.getElementById('cardTotalImages');
  const cardTodayImages = document.getElementById('cardTodayImages');
  const cardStorageStatus = document.getElementById('cardStorageStatus');
  const cardTotalThumbs = document.getElementById('cardTotalThumbs');
  const recentImagesGrid = document.getElementById('recentImagesGrid');
  const dashCaptureBtn = document.getElementById('dashCaptureBtn');
  const dashUploadBtn = document.getElementById('dashUploadBtn');
  const viewAllGalleryBtn = document.getElementById('viewAllGalleryBtn');
  const sidebarStorageMeter = document.getElementById('sidebarStorageMeter');

  // Capture Workspace
  const tabStripBtns = document.querySelectorAll('.tab-strip .tab-btn');
  const sourcePanes = document.querySelectorAll('.source-pane');
  const videoElement = document.getElementById('videoElement');
  const camFallback = document.getElementById('camFallback');
  const btnStartCamera = document.getElementById('btnStartCamera');
  const btnToggleCamera = document.getElementById('btnToggleCamera');
  const btnSnapPhoto = document.getElementById('btnSnapPhoto');
  const hudBadge = document.getElementById('hudBadge');
  const fileDropArea = document.getElementById('fileDropArea');
  const filePickerInput = document.getElementById('filePickerInput');
  const btnSimTrigger = document.getElementById('btnSimTrigger');
  const simNodeTemp = document.getElementById('simNodeTemp');
  const simNodeHum = document.getElementById('simNodeHum');

  // Preview / Staged Panel
  const previewPlaceholder = document.getElementById('previewPlaceholder');
  const stagedPreviewBody = document.getElementById('stagedPreviewBody');
  const stagedFullImg = document.getElementById('stagedFullImg');
  const stagedThumbImg = document.getElementById('stagedThumbImg');
  const stagedFullRes = document.getElementById('stagedFullRes');
  const stagedThumbRes = document.getElementById('stagedThumbRes');
  const stagedFullSize = document.getElementById('stagedFullSize');
  const stagedThumbSize = document.getElementById('stagedThumbSize');
  const previewStatusBadge = document.getElementById('previewStatusBadge');
  const inputTitle = document.getElementById('inputTitle');
  const selectDevice = document.getElementById('selectDevice');
  const inputTelemetry = document.getElementById('inputTelemetry');
  const btnDiscardPreview = document.getElementById('btnDiscardPreview');
  const btnUploadCloud = document.getElementById('btnUploadCloud');

  // Full Gallery
  const fullGalleryGrid = document.getElementById('fullGalleryGrid');
  const galleryEmptyState = document.getElementById('galleryEmptyState');
  const gallerySearchInput = document.getElementById('gallerySearchInput');
  const galleryDeviceFilter = document.getElementById('galleryDeviceFilter');
  const galleryDateFilter = document.getElementById('galleryDateFilter');
  const galleryCountText = document.getElementById('galleryCountText');
  const btnExportJson = document.getElementById('btnExportJson');
  const btnClearAllGallery = document.getElementById('btnClearAllGallery');

  // Settings
  const btnResetSampleData = document.getElementById('btnResetSampleData');
  const btnSaveConfig = document.getElementById('btnSaveConfig');

  // Modal Lightbox
  const imageModal = document.getElementById('imageModal');
  const modalOverlay = document.getElementById('modalOverlay');
  const mCloseBtn = document.getElementById('mCloseBtn');
  const mTitle = document.getElementById('mTitle');
  const mTimestampBadge = document.getElementById('mTimestampBadge');
  const mMainImage = document.getElementById('mMainImage');
  const mDate = document.getElementById('mDate');
  const mTime = document.getElementById('mTime');
  const mDevice = document.getElementById('mDevice');
  const mResolution = document.getElementById('mResolution');
  const mFullSize = document.getElementById('mFullSize');
  const mThumbSize = document.getElementById('mThumbSize');
  const mNotes = document.getElementById('mNotes');
  const mDownloadFull = document.getElementById('mDownloadFull');
  const mDownloadThumb = document.getElementById('mDownloadThumb');
  const mDeleteBtn = document.getElementById('mDeleteBtn');

  // Toast & Utilities
  const toastStack = document.getElementById('toastStack');
  const procCanvas = document.getElementById('procCanvas');

  // =========================================================
  // 1. IndexedDB Persistence Layer
  // =========================================================
  function initDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);

      req.onupgradeneeded = (e) => {
        const database = e.target.result;
        if (!database.objectStoreNames.contains(STORE_NAME)) {
          const store = database.createObjectStore(STORE_NAME, { keyPath: 'id' });
          store.createIndex('timestamp', 'timestamp', { unique: false });
          store.createIndex('deviceId', 'deviceId', { unique: false });
        }
      };

      req.onsuccess = (e) => {
        db = e.target.result;
        resolve(db);
      };

      req.onerror = (e) => {
        console.error('IndexedDB open error:', e.target.error);
        reject(e.target.error);
      };
    });
  }

  function dbGetAll() {
    return new Promise((resolve) => {
      if (!db) return resolve([]);
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    });
  }

  function dbPut(record) {
    return new Promise((resolve, reject) => {
      if (!db) return resolve(record);
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(record);
      req.onsuccess = () => resolve(record);
      req.onerror = (e) => reject(e.target.error);
    });
  }

  function dbDelete(id) {
    return new Promise((resolve, reject) => {
      if (!db) return resolve();
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = (e) => reject(e.target.error);
    });
  }

  function dbClear() {
    return new Promise((resolve, reject) => {
      if (!db) return resolve();
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.clear();
      req.onsuccess = () => resolve();
      req.onerror = (e) => reject(e.target.error);
    });
  }

  // =========================================================
  // 2. View Switcher & Navigation Routing
  // =========================================================
  function switchView(viewName) {
    // Update Sidebar Nav Buttons
    navItems.forEach(item => {
      if (item.getAttribute('data-view') === viewName) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    // Update Main View Containers
    viewContainers.forEach(container => {
      if (container.id === `view-${viewName}`) {
        container.classList.add('active');
      } else {
        container.classList.remove('active');
      }
    });

    // Close mobile menu if open
    if (sidebar.classList.contains('mobile-open')) {
      sidebar.classList.remove('mobile-open');
    }

    // Refresh view specific components
    if (viewName === 'dashboard') {
      renderDashboard();
    } else if (viewName === 'gallery') {
      renderFullGallery();
    }
  }

  function switchCaptureSourceTab(sourceName) {
    tabStripBtns.forEach(btn => {
      if (btn.getAttribute('data-source') === sourceName) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    sourcePanes.forEach(pane => {
      if (pane.id === `pane-${sourceName}`) {
        pane.classList.add('active');
      } else {
        pane.classList.remove('active');
      }
    });
  }

  // =========================================================
  // 3. Live Digital Clock
  // =========================================================
  function startLiveClock() {
    const updateTime = () => {
      const now = new Date();
      liveClock.textContent = now.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
      });
    };
    updateTime();
    setInterval(updateTime, 1000);
  }

  // =========================================================
  // 4. Camera Stream & Snapshot Logic
  // =========================================================
  async function startWebcam() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' },
        audio: false
      });

      mediaStream = stream;
      videoElement.srcObject = mediaStream;
      videoElement.play();

      camFallback.style.display = 'none';
      btnSnapPhoto.disabled = false;
      btnToggleCamera.textContent = 'Stop Camera';
      hudBadge.textContent = 'STREAM: LIVE 30FPS';
      hudBadge.style.color = '#10b981';
      showToast('IoT Camera feed connected', 'success');
    } catch (err) {
      console.warn('Webcam permission error:', err);
      showToast('Camera permission denied or camera not found', 'error');
    }
  }

  function stopWebcam() {
    if (mediaStream) {
      mediaStream.getTracks().forEach(track => track.stop());
      mediaStream = null;
    }
    videoElement.srcObject = null;
    camFallback.style.display = 'flex';
    btnSnapPhoto.disabled = true;
    btnToggleCamera.textContent = 'Start Camera';
    hudBadge.textContent = 'STREAM: STANDBY';
    hudBadge.style.color = '#06b6d4';
  }

  function captureWebcamSnapshot() {
    if (!videoElement || !mediaStream) {
      showToast('Start camera first', 'error');
      return;
    }

    const w = videoElement.videoWidth || 640;
    const h = videoElement.videoHeight || 480;

    procCanvas.width = w;
    procCanvas.height = h;
    const ctx = procCanvas.getContext('2d');

    // Flip horizontal to correct mirrored selfie webcam view
    ctx.translate(w, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(videoElement, 0, 0, w, h);

    const fullDataUrl = procCanvas.toDataURL('image/jpeg', 0.9);
    stageCapturedImage(fullDataUrl, 'Live Camera Snapshot', 'ESP32-CAM-01', 'Snap taken from IoT Camera Feed');
    showToast('Photo captured! Auto-thumbnail generated.', 'success');
  }

  // =========================================================
  // 5. File Upload Handler
  // =========================================================
  function handleFileSelected(file) {
    if (!file || !file.type.startsWith('image/')) {
      showToast('Please select a valid image file', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const cleanName = file.name.replace(/\.[^/.]+$/, '');
      stageCapturedImage(
        e.target.result,
        cleanName,
        'Manual-Terminal',
        `File upload: ${file.name} (${formatBytes(file.size)})`
      );
      showToast('Image loaded into staging preview', 'info');
    };
    reader.readAsDataURL(file);
  }

  // =========================================================
  // 6. Simulated ESP32-CAM Edge Trigger
  // =========================================================
  function triggerSimulatedHardwareCapture() {
    const canvas = document.createElement('canvas');
    canvas.width = 800;
    canvas.height = 600;
    const ctx = canvas.getContext('2d');

    // Sky & background gradient
    const skyGrad = ctx.createLinearGradient(0, 0, 0, 360);
    skyGrad.addColorStop(0, '#0369a1');
    skyGrad.addColorStop(1, '#38bdf8');
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, 800, 360);

    // Ground
    const groundGrad = ctx.createLinearGradient(0, 360, 0, 600);
    groundGrad.addColorStop(0, '#334155');
    groundGrad.addColorStop(1, '#0f172a');
    ctx.fillStyle = groundGrad;
    ctx.fillRect(0, 360, 800, 240);

    // Building/Facility silhouette
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(60, 160, 220, 260);
    ctx.fillRect(520, 160, 220, 260);

    // Smart gate bars
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 3;
    for (let x = 290; x <= 510; x += 22) {
      ctx.beginPath();
      ctx.moveTo(x, 220);
      ctx.lineTo(x, 420);
      ctx.stroke();
    }

    // Motion Detection bounding box
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 3;
    ctx.strokeRect(360, 280, 80, 120);
    ctx.fillStyle = '#10b981';
    ctx.font = 'bold 13px monospace';
    ctx.fillText('PIR TARGET [98%]', 340, 270);

    // Dynamic environmental sensor telemetry
    const tempVal = (27 + Math.random() * 3.5).toFixed(1);
    const humVal = Math.floor(60 + Math.random() * 12);
    simNodeTemp.textContent = `${tempVal} °C`;
    simNodeHum.textContent = `${humVal} %`;

    // Edge OSD Telemetry Banner overlay
    ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
    ctx.fillRect(0, 0, 800, 42);
    ctx.fillStyle = '#38bdf8';
    ctx.font = '14px monospace';
    ctx.fillText(`EDGE NODE: ESP32-CAM-01 | PIR MOTION TRIGGER | TEMP: ${tempVal}°C | HUM: ${humVal}%`, 16, 26);

    const fullDataUrl = canvas.toDataURL('image/jpeg', 0.9);
    const eventNum = Math.floor(1000 + Math.random() * 9000);
    stageCapturedImage(
      fullDataUrl,
      `PIR Event #${eventNum}`,
      'ESP32-CAM-01',
      `Auto-triggered motion event | Temp: ${tempVal}°C | Humidity: ${humVal}%`
    );
    showToast('Simulated ESP32-CAM capture received!', 'success');
  }

  // =========================================================
  // 7. Automatic HTML5 Canvas Thumbnail Generator
  // =========================================================
  function generateCanvasThumbnail(fullDataUrl, targetWidth = 280, targetHeight = 210) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        let w = img.width;
        let h = img.height;

        // Keep aspect ratio
        if (w > h) {
          if (w > targetWidth) {
            h = Math.round((h * targetWidth) / w);
            w = targetWidth;
          }
        } else {
          if (h > targetHeight) {
            w = Math.round((w * targetHeight) / h);
            h = targetHeight;
          }
        }

        const tCanvas = document.createElement('canvas');
        tCanvas.width = w;
        tCanvas.height = h;
        const ctx = tCanvas.getContext('2d');

        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, w, h);

        const thumbDataUrl = tCanvas.toDataURL('image/jpeg', 0.82);
        const thumbBytes = Math.round((thumbDataUrl.length * 3) / 4);

        resolve({
          thumbDataUrl,
          width: w,
          height: h,
          thumbBytes
        });
      };
      img.src = fullDataUrl;
    });
  }

  // =========================================================
  // 8. Staging & Dual-Preview
  // =========================================================
  async function stageCapturedImage(fullDataUrl, defaultTitle, defaultDevice, defaultTelemetry) {
    const img = new Image();
    img.onload = async () => {
      const originalBytes = Math.round((fullDataUrl.length * 3) / 4);
      const thumb = await generateCanvasThumbnail(fullDataUrl, 280, 210);

      stagedCapture = {
        fullDataUrl: fullDataUrl,
        thumbDataUrl: thumb.thumbDataUrl,
        width: img.width,
        height: img.height,
        sizeBytes: originalBytes,
        thumbWidth: thumb.width,
        thumbHeight: thumb.height,
        thumbSizeBytes: thumb.thumbBytes
      };

      // Populate preview DOM
      stagedFullImg.src = fullDataUrl;
      stagedThumbImg.src = thumb.thumbDataUrl;
      stagedFullRes.textContent = `${img.width}x${img.height}`;
      stagedThumbRes.textContent = `${thumb.width}x${thumb.height}`;
      stagedFullSize.textContent = `Size: ${formatBytes(originalBytes)}`;
      stagedThumbSize.textContent = `Size: ${formatBytes(thumb.thumbBytes)}`;

      inputTitle.value = defaultTitle || `Capture_${Date.now().toString().slice(-4)}`;
      selectDevice.value = defaultDevice || 'ESP32-CAM-01';
      inputTelemetry.value = defaultTelemetry || 'Motion detected by edge sensor';

      previewStatusBadge.textContent = 'Ready to Cloud Sync';
      previewStatusBadge.style.color = '#10b981';

      previewPlaceholder.style.display = 'none';
      stagedPreviewBody.style.display = 'flex';
    };
    img.src = fullDataUrl;
  }

  function discardStagedPreview() {
    stagedCapture = null;
    stagedFullImg.src = '';
    stagedThumbImg.src = '';
    previewPlaceholder.style.display = 'flex';
    stagedPreviewBody.style.display = 'none';
    previewStatusBadge.textContent = 'Awaiting Image';
    previewStatusBadge.style.color = '#06b6d4';
    filePickerInput.value = '';
  }

  // =========================================================
  // 9. Upload & Cloud Persistence
  // =========================================================
  async function uploadStagedImageToCloud() {
    if (!stagedCapture) {
      showToast('No staged image available', 'error');
      return;
    }

    const title = inputTitle.value.trim() || 'Untitled Capture';
    const device = selectDevice.value;
    const telemetry = inputTelemetry.value.trim() || 'Normal Edge Telemetry';
    const now = new Date();

    const newRecord = {
      id: 'iot_img_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      title: title,
      deviceId: device,
      notes: telemetry,
      timestamp: now.getTime(),
      dateFormatted: formatDate(now),
      timeFormatted: formatTime(now),
      fullUrl: stagedCapture.fullDataUrl,
      thumbUrl: stagedCapture.thumbDataUrl,
      resolution: `${stagedCapture.width}x${stagedCapture.height}`,
      sizeBytes: stagedCapture.sizeBytes,
      thumbSizeBytes: stagedCapture.thumbSizeBytes,
      storageType: 'IndexedDB Cloud'
    };

    btnUploadCloud.disabled = true;
    btnUploadCloud.innerHTML = `Syncing to Cloud...`;

    try {
      await dbPut(newRecord);
      allImages.unshift(newRecord);

      discardStagedPreview();
      updateMetricsCards();
      renderDashboard();
      renderFullGallery();

      showToast(`Image "${title}" stored in cloud gallery!`, 'success');
      // Navigate user to Gallery so they see the result immediately
      switchView('gallery');
    } catch (err) {
      console.error('Cloud save failed:', err);
      showToast('Failed to save to cloud gallery', 'error');
    } finally {
      btnUploadCloud.disabled = false;
      btnUploadCloud.innerHTML = `
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>
          <polyline points="16 16 12 12 8 16"/>
          <line x1="12" y1="12" x2="12" y2="21"/>
        </svg>
        Save & Sync to Cloud Gallery
      `;
    }
  }

  // =========================================================
  // 10. Dashboard & Recent Images Rendering
  // =========================================================
  function renderDashboard() {
    updateMetricsCards();
    renderRecentImages();
  }

  function updateMetricsCards() {
    const totalCount = allImages.length;
    cardTotalImages.textContent = totalCount;
    cardTotalThumbs.textContent = totalCount;
    navGalleryCount.textContent = totalCount;

    // Calculate images captured Today
    const todayStr = formatDate(new Date());
    const todayCount = allImages.filter(img => img.dateFormatted === todayStr).length;
    cardTodayImages.textContent = todayCount;

    // Calculate total storage consumption
    const totalBytes = allImages.reduce((sum, img) => sum + (img.sizeBytes || 0) + (img.thumbSizeBytes || 0), 0);
    cardStorageStatus.textContent = formatBytes(totalBytes);

    // Update mini meter in sidebar (e.g. 100MB virtual quota)
    const quotaBytes = 100 * 1024 * 1024;
    const pct = Math.min(100, Math.max(8, (totalBytes / quotaBytes) * 100));
    sidebarStorageMeter.style.width = `${pct}%`;
  }

  function renderRecentImages() {
    recentImagesGrid.innerHTML = '';
    const recents = allImages.slice(0, 6);

    if (recents.length === 0) {
      recentImagesGrid.innerHTML = `
        <div class="empty-state-box" style="grid-column: 1 / -1;">
          <p>No recent images captured yet.</p>
          <button class="btn btn-primary btn-sm" onclick="document.querySelector('[data-view=\\'capture\\']').click()">
            Capture First Image
          </button>
        </div>
      `;
      return;
    }

    recents.forEach(item => {
      const card = createGalleryCardElement(item);
      recentImagesGrid.appendChild(card);
    });
  }

  // =========================================================
  // 11. Full Gallery View Rendering
  // =========================================================
  function renderFullGallery() {
    const query = (gallerySearchInput.value || '').toLowerCase().trim();
    const devFilter = galleryDeviceFilter.value;
    const dateFilter = galleryDateFilter.value;
    const todayStr = formatDate(new Date());

    const filtered = allImages.filter(item => {
      const matchDevice = (devFilter === 'ALL' || item.deviceId === devFilter);
      const matchDate = (dateFilter === 'ALL' || (dateFilter === 'TODAY' && item.dateFormatted === todayStr));
      const matchQuery = !query ||
        item.title.toLowerCase().includes(query) ||
        item.deviceId.toLowerCase().includes(query) ||
        item.notes.toLowerCase().includes(query) ||
        item.dateFormatted.toLowerCase().includes(query) ||
        item.timeFormatted.toLowerCase().includes(query);

      return matchDevice && matchDate && matchQuery;
    });

    galleryCountText.textContent = `${filtered.length} Images`;

    if (filtered.length === 0) {
      fullGalleryGrid.innerHTML = '';
      galleryEmptyState.style.display = 'flex';
      return;
    }

    galleryEmptyState.style.display = 'none';
    fullGalleryGrid.innerHTML = '';

    filtered.forEach(item => {
      const card = createGalleryCardElement(item);
      fullGalleryGrid.appendChild(card);
    });
  }

  // =========================================================
  // 12. Gallery Card Builder (Displays Date & Time Clearly)
  // =========================================================
  function createGalleryCardElement(item) {
    const card = document.createElement('div');
    card.className = 'gallery-card';

    card.innerHTML = `
      <div class="card-media" title="Click to view full image">
        <img src="${item.thumbUrl}" alt="${escapeHtml(item.title)}" loading="lazy">
        <span class="card-badge-node">${escapeHtml(item.deviceId)}</span>
        <span class="card-badge-thumb">THUMB</span>
      </div>
      <div class="card-details">
        <h4 class="card-header-title" title="${escapeHtml(item.title)}">${escapeHtml(item.title)}</h4>

        <!-- Prominent Date and Time Pill -->
        <div class="datetime-pill" title="Capture Timestamp">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
            <line x1="16" y1="2" x2="16" y2="6"></line>
            <line x1="8" y1="2" x2="8" y2="6"></line>
            <line x1="3" y1="10" x2="21" y2="10"></line>
          </svg>
          <span><strong>${item.dateFormatted}</strong> &bull; ${item.timeFormatted}</span>
        </div>

        <p class="card-sensor-text" title="${escapeHtml(item.notes)}">
          ${escapeHtml(item.notes)}
        </p>

        <div class="card-action-bar">
          <span class="card-res-tag">${item.resolution}</span>
          <div style="display:flex; gap: 0.35rem;">
            <button class="btn-card-icon btn-view" title="Inspect Full Image">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                <circle cx="12" cy="12" r="3"></circle>
              </svg>
              View
            </button>
            <button class="btn-card-icon danger btn-delete" title="Delete from Cloud">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="3 6 5 6 21 6"></polyline>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
              </svg>
            </button>
          </div>
        </div>
      </div>
    `;

    const mediaWrap = card.querySelector('.card-media');
    const viewBtn = card.querySelector('.btn-view');
    const deleteBtn = card.querySelector('.btn-delete');

    mediaWrap.addEventListener('click', () => openImageModal(item));
    viewBtn.addEventListener('click', () => openImageModal(item));
    deleteBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      deleteImageItem(item.id);
    });

    return card;
  }

  // =========================================================
  // 13. Lightbox Modal Inspector
  // =========================================================
  function openImageModal(item) {
    currentViewingImage = item;
    mTitle.textContent = item.title;
    mTimestampBadge.textContent = `${item.dateFormatted} at ${item.timeFormatted}`;
    mMainImage.src = item.fullUrl;
    mDate.textContent = item.dateFormatted;
    mTime.textContent = item.timeFormatted;
    mDevice.textContent = item.deviceId;
    mResolution.textContent = item.resolution;
    mFullSize.textContent = formatBytes(item.sizeBytes);
    mThumbSize.textContent = formatBytes(item.thumbSizeBytes);
    mNotes.textContent = item.notes;

    mDownloadFull.href = item.fullUrl;
    mDownloadFull.download = `${item.title.replace(/\s+/g, '_')}_full.jpg`;

    mDownloadThumb.href = item.thumbUrl;
    mDownloadThumb.download = `${item.title.replace(/\s+/g, '_')}_thumb.jpg`;

    imageModal.classList.add('active');
  }

  function closeImageModal() {
    imageModal.classList.remove('active');
    currentViewingImage = null;
  }

  async function deleteImageItem(id) {
    if (confirm('Delete this image from the IoT Cloud Gallery?')) {
      await dbDelete(id);
      allImages = allImages.filter(img => img.id !== id);
      updateMetricsCards();
      renderDashboard();
      renderFullGallery();
      showToast('Image deleted from cloud storage', 'info');
      if (currentViewingImage && currentViewingImage.id === id) {
        closeImageModal();
      }
    }
  }

  async function clearEntireGallery() {
    if (allImages.length === 0) {
      showToast('Gallery is already empty', 'info');
      return;
    }

    if (confirm('Are you sure you want to delete ALL images from the gallery?')) {
      await dbClear();
      allImages = [];
      updateMetricsCards();
      renderDashboard();
      renderFullGallery();
      showToast('All images purged from cloud gallery', 'info');
    }
  }

  function exportGalleryAsJSON() {
    if (allImages.length === 0) {
      showToast('No images to export', 'info');
      return;
    }

    const exportMeta = allImages.map(img => ({
      id: img.id,
      title: img.title,
      deviceId: img.deviceId,
      notes: img.notes,
      timestamp: img.timestamp,
      date: img.dateFormatted,
      time: img.timeFormatted,
      resolution: img.resolution,
      sizeBytes: img.sizeBytes,
      thumbSizeBytes: img.thumbSizeBytes
    }));

    const blob = new Blob([JSON.stringify(exportMeta, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `iot_gallery_metadata_${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
    showToast('Gallery metadata exported as JSON', 'success');
  }

  // =========================================================
  // 14. Initial Demo Sample Seeder (College Project Ready)
  // =========================================================
  async function seedDemoSamples() {
    const samples = [
      {
        title: 'Entrance Security Snapshot',
        deviceId: 'ESP32-CAM-01',
        notes: 'PIR motion triggered, Temp: 28.2°C, Humidity: 62%',
        themeColor: '#0284c7',
        offsetMinutes: 12
      },
      {
        title: 'Smart Garden Crop Surveillance',
        deviceId: 'ESP32-CAM-02',
        notes: 'Periodic schedule check, Temp: 26.5°C, Soil: 72%',
        themeColor: '#059669',
        offsetMinutes: 45
      },
      {
        title: 'Laboratory Door Access Verify',
        deviceId: 'RPi-Node-01',
        notes: 'RFID card trigger event, Temp: 23.8°C',
        themeColor: '#7c3aed',
        offsetMinutes: 110
      },
      {
        title: 'Perimeter Night Patrol Check',
        deviceId: 'ESP32-CAM-01',
        notes: 'Infrared night surveillance scan, Temp: 21.4°C',
        themeColor: '#d97706',
        offsetMinutes: 240
      }
    ];

    for (const sample of samples) {
      const c = document.createElement('canvas');
      c.width = 640;
      c.height = 480;
      const ctx = c.getContext('2d');

      // Gradient
      const grad = ctx.createLinearGradient(0, 0, 640, 480);
      grad.addColorStop(0, '#0f172a');
      grad.addColorStop(1, sample.themeColor);
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 640, 480);

      // Grid Pattern
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = 1;
      for (let x = 0; x < 640; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, 480);
        ctx.stroke();
      }
      for (let y = 0; y < 480; y += 40) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(640, y);
        ctx.stroke();
      }

      // IoT On-Screen Display (OSD) Telemetry
      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 22px monospace';
      ctx.fillText(`[IoT NODE: ${sample.deviceId}]`, 35, 180);

      ctx.fillStyle = '#38bdf8';
      ctx.font = '16px monospace';
      ctx.fillText(sample.title, 35, 220);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '13px monospace';
      ctx.fillText(sample.notes, 35, 260);

      const fullDataUrl = c.toDataURL('image/jpeg', 0.88);
      const thumb = await generateCanvasThumbnail(fullDataUrl, 280, 210);

      const d = new Date(Date.now() - sample.offsetMinutes * 60 * 1000);
      const record = {
        id: 'iot_sample_' + Math.random().toString(36).substring(2, 8),
        title: sample.title,
        deviceId: sample.deviceId,
        notes: sample.notes,
        timestamp: d.getTime(),
        dateFormatted: formatDate(d),
        timeFormatted: formatTime(d),
        fullUrl: fullDataUrl,
        thumbUrl: thumb.thumbDataUrl,
        resolution: '640x480',
        sizeBytes: Math.round((fullDataUrl.length * 3) / 4),
        thumbSizeBytes: thumb.thumbBytes,
        storageType: 'IndexedDB Cloud'
      };

      await dbPut(record);
      allImages.push(record);
    }
  }

  // =========================================================
  // 15. Helper Utilities
  // =========================================================
  function formatDate(d) {
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }

  function formatTime(d) {
    return d.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  }

  function formatBytes(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }

  function escapeHtml(str) {
    return (str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    toastStack.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 250);
    }, 3200);
  }

  // =========================================================
  // 16. Event Listeners Setup
  // =========================================================
  function bindEvents() {
    // Mobile Sidebar Toggle
    if (menuToggleBtn) {
      menuToggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('mobile-open');
      });
    }

    // Sidebar Navigation
    navItems.forEach(btn => {
      btn.addEventListener('click', () => {
        const view = btn.getAttribute('data-view');
        switchView(view);
      });
    });

    // Header Quick Action & Banner Buttons
    if (quickCaptureNavBtn) {
      quickCaptureNavBtn.addEventListener('click', () => {
        switchView('capture');
        switchCaptureSourceTab('camera');
      });
    }
    if (dashCaptureBtn) {
      dashCaptureBtn.addEventListener('click', () => {
        switchView('capture');
        switchCaptureSourceTab('camera');
      });
    }
    if (dashUploadBtn) {
      dashUploadBtn.addEventListener('click', () => {
        switchView('capture');
        switchCaptureSourceTab('upload');
      });
    }
    if (viewAllGalleryBtn) {
      viewAllGalleryBtn.addEventListener('click', () => {
        switchView('gallery');
      });
    }

    // Capture Source Tab Strip
    tabStripBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const src = btn.getAttribute('data-source');
        switchCaptureSourceTab(src);
      });
    });

    // Camera Controls
    if (btnStartCamera) btnStartCamera.addEventListener('click', startWebcam);
    if (btnToggleCamera) {
      btnToggleCamera.addEventListener('click', () => {
        if (mediaStream) stopWebcam();
        else startWebcam();
      });
    }
    if (btnSnapPhoto) btnSnapPhoto.addEventListener('click', captureWebcamSnapshot);

    // File Upload Picker & Drag-and-Drop
    if (filePickerInput) {
      filePickerInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files[0]) {
          handleFileSelected(e.target.files[0]);
        }
      });
    }
    if (fileDropArea) {
      fileDropArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        fileDropArea.classList.add('dragover');
      });
      fileDropArea.addEventListener('dragleave', () => {
        fileDropArea.classList.remove('dragover');
      });
      fileDropArea.addEventListener('drop', (e) => {
        e.preventDefault();
        fileDropArea.classList.remove('dragover');
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
          handleFileSelected(e.dataTransfer.files[0]);
        }
      });
    }

    // Simulated Hardware Trigger
    if (btnSimTrigger) {
      btnSimTrigger.addEventListener('click', triggerSimulatedHardwareCapture);
    }

    // Preview / Staging Actions
    if (btnDiscardPreview) btnDiscardPreview.addEventListener('click', discardStagedPreview);
    if (btnUploadCloud) btnUploadCloud.addEventListener('click', uploadStagedImageToCloud);

    // Gallery Toolbar Actions
    if (gallerySearchInput) gallerySearchInput.addEventListener('input', renderFullGallery);
    if (galleryDeviceFilter) galleryDeviceFilter.addEventListener('change', renderFullGallery);
    if (galleryDateFilter) galleryDateFilter.addEventListener('change', renderFullGallery);
    if (btnExportJson) btnExportJson.addEventListener('click', exportGalleryAsJSON);
    if (btnClearAllGallery) btnClearAllGallery.addEventListener('click', clearEntireGallery);

    // Settings Actions
    if (btnResetSampleData) {
      btnResetSampleData.addEventListener('click', async () => {
        await dbClear();
        allImages = [];
        await seedDemoSamples();
        updateMetricsCards();
        renderDashboard();
        renderFullGallery();
        showToast('Sample demo images restored!', 'success');
        switchView('dashboard');
      });
    }
    if (btnSaveConfig) {
      btnSaveConfig.addEventListener('click', () => {
        showToast('Settings saved successfully', 'success');
      });
    }

    // Modal Lightbox Close Actions
    if (mCloseBtn) mCloseBtn.addEventListener('click', closeImageModal);
    if (modalOverlay) modalOverlay.addEventListener('click', closeImageModal);
    if (mDeleteBtn) {
      mDeleteBtn.addEventListener('click', () => {
        if (currentViewingImage) deleteImageItem(currentViewingImage.id);
      });
    }

    // Global ESC key listener for modal
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeImageModal();
    });
  }

  // =========================================================
  // 17. Initialization Bootstrap
  // =========================================================
  async function initApp() {
    startLiveClock();
    bindEvents();

    try {
      await initDB();
      const existing = await dbGetAll();

      if (existing && existing.length > 0) {
        allImages = existing.sort((a, b) => b.timestamp - a.timestamp);
      } else {
        // Initial sample seed so college project is immediately presentation-ready
        await seedDemoSamples();
      }

      updateMetricsCards();
      renderDashboard();
      renderFullGallery();
    } catch (e) {
      console.error('Initialization error:', e);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
  } else {
    initApp();
  }
})();
